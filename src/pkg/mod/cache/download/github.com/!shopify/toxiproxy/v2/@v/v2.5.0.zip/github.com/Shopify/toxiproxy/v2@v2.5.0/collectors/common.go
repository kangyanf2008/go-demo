package collectors

const (
	namespace string = "toxiproxy"
)
