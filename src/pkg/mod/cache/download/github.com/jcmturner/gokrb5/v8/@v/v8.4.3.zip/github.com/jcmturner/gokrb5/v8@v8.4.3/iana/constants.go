// Package iana provides Kerberos 5 assigned numbers.
package iana

// PVNO is the Protocol Version Number.
const PVNO = 5
